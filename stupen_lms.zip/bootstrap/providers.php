<?php

return [
    Maatwebsite\Excel\ExcelServiceProvider::class,
    Spatie\Permission\PermissionServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
    App\Providers\AppServiceProvider::class,
];
