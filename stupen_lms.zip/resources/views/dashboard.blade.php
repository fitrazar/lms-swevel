@section('title', 'Dashboard')

<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <x-card.card-default class="static">
                <p>Dashboard</p>
            </x-card.card-default>
            @hasrole('participant')
                @include('partials.participant')
            @endrole
        </div>
    </div>
</x-app-layout>
