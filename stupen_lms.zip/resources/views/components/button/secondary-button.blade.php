<button {!! $attributes->merge(['class' => 'btn btn-secondary']) !!}>
    {{ $slot }}
</button>
