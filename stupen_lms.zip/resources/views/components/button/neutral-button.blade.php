<button {!! $attributes->merge(['class' => 'btn btn-neutral']) !!}>
    {{ $slot }}
</button>
