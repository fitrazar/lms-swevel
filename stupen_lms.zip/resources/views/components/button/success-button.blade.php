<button {{ $attributes->merge(['class' => 'btn btn-success']) }}>
    {{ $slot }}
</button>
