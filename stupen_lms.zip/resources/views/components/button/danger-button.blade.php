<button {{ $attributes->merge(['class' => 'btn btn-error']) }}>
    {{ $slot }}
</button>
