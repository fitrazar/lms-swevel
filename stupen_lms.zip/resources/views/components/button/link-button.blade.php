<button {{ $attributes->merge(['class' => 'btn btn-link']) }}>
    {{ $slot }}
</button>
